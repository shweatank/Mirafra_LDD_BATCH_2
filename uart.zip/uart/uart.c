#include<lpc21xx.h>
//________U0LCR______
#define DLAB 1<<7
#define wordlenght 3<<0;

//_____U0LSR_______
#define RDR 1<<0
#define THRE 1<<5
#define EMT 1<<6
#define tx  1<<0
#define rx  1<<2

#define fosc 12000000
#define cclk fosc*5
#define pclk cclk/4
#define burdrate 9600
#define diviser pclk/(16*burdrate)
void init_uart(void)
{
	PINSEL0=tx|rx;//cong tx and rx
	U0LCR=DLAB|wordlenght;
	U0DLL=diviser;
	D0DLM=diviser>>8;
	U0LCR&=~(DLAB);
}
unsigned char uart_rx(void)
{
	while(((U0LSR>>RDR)&1)==0);
	return RBR;
}
void uart_tx(unsigned char data)
{
	U0THR=data; 
	while(((U0LSR>>EMT)&1)==0);
}
