#ifndef _UART_H
#define _UART_H
void init_uart(void);
unsigned char uart_rx(void);
void uart_tx(unsigned char);

#endif

