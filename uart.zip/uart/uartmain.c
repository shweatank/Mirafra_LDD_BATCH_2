#include<lpc21xx.h>
#include"uart.h"
int main()
{
	init_uart();
	while(1)
	{
		ch=uart_rx();
		uart_tx(ch);
	}

}
